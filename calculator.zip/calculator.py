import tkinter as tk
from tkinter import ttk

# Function to update the display with the clicked number or operator
def update_display(value):
    current_text = display_var.get()
    display_var.set(current_text + value)

# Function to calculate and display the result
def calculate():
    try:
        expression = display_var.get()
        result = eval(expression)
        display_var.set(result)
    except Exception as e:
        display_var.set("Error")

# Function to clear the display
def clear_display():
    display_var.set("")

# Create the main tkinter window
root = tk.Tk()
root.title("Simple Calculator")

# Create a display
display_var = tk.StringVar()
display_var.set("")

display = ttk.Entry(root, textvariable=display_var, font=("Helvetica", 24))
display.grid(row=0, column=0, columnspan=4)

# Create style for the buttons with black background
button_style = ttk.Style()
button_style.configure("Black.TButton", background="black")

# Create buttons for digits and operators with the "Black.TButton" style
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
]

row, col = 1, 0
for button_text in buttons:
    ttk.Button(root, text=button_text, command=lambda b=button_text: update_display(b), style="Black.TButton").grid(row=row, column=col, padx=5, pady=5)
    col += 1
    if col > 3:
        col = 0
        row += 1

# Create a Calculate button
calculate_button = ttk.Button(root, text="Calculate", command=calculate, style="Black.TButton")
calculate_button.grid(row=row, column=col, padx=5, pady=5)

# Run the tkinter main loop
root.mainloop()
